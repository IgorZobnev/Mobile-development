package com.example.mysevenapplication

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import java.util.ArrayList

class ListAdapter : RecyclerView.Adapter<ElemViewHolder>() {
    private var data: ArrayList<String>? = null

    override fun getItemCount(): Int {
        return data!!.size
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ElemViewHolder {
        val context = viewGroup.context
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.list_item, viewGroup, false)
        return ElemViewHolder(view)
    }

    override fun onBindViewHolder(holder: ElemViewHolder, index: Int) {
        val str = data!![index]
        Log.d("str", str)
        holder.textView.setText(str)
    }

    fun clear() {
        data?.clear()
        notifyDataSetChanged()
    }

    fun setData(data: ArrayList<String>?) {
        var data = data
        if (data == null) {
            data = ArrayList()
        }
        this.data = data
        notifyDataSetChanged()
    }
}