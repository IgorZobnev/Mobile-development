package com.example.mysevenapplication

import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import java.io.IOException
import java.util.ArrayList
import android.app.AlertDialog
import android.content.DialogInterface

class MainActivity : AppCompatActivity() {

    private var mItemsList: RecyclerView? = null
    private var mListAdapter: ListAdapter? = null
    private var editView: EditText? = null
    private var db: TestDB? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mItemsList = findViewById(R.id.my_recycler_view) as RecyclerView

        val gridLayoutManager = LinearLayoutManager(this)
        mItemsList!!.setLayoutManager(gridLayoutManager)

        mListAdapter = ListAdapter()
        mItemsList!!.setAdapter(mListAdapter)
        mItemsList!!.setHasFixedSize(true)

        editView = findViewById(R.id.text)

        db = Room.databaseBuilder(
            this,
            TestDB::class.java, "first"
        ).allowMainThreadQueries().fallbackToDestructiveMigration().build()

        requestInternet().execute(text(db!!.tableDao().getAll()))

        ItemTouchHelper(
            object :
                ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
                override fun onMove(
                    recyclerView: RecyclerView,
                    viewHolder: RecyclerView.ViewHolder,
                    targannotationProcessoret: RecyclerView.ViewHolder
                ): Boolean {
                    return false
                }

                override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                    val tracks = db?.tableDao()?.getAll()
                    val id = tracks?.get(viewHolder.adapterPosition)?.id
                    //val id = viewHolder.itemView.tag as Int
                    db?.tableDao()?.deleteById(id!!.toInt())
                    requestInternet().execute(text(db!!.tableDao().getAll()))
                }
            }
        ).attachToRecyclerView(mItemsList)

        var load: Button
        load = findViewById(R.id.load)
        load.setOnClickListener(View.OnClickListener {
            var text: String
            text = editView?.getText().toString()
            Log.d("spec tag", text)
            if (text.isEmpty()) {
                val builder = AlertDialog.Builder(this@MainActivity)
                builder.setTitle("Error!")
                    .setMessage("You should insert non-empty text.")
                    .setCancelable(false)
                    .setNegativeButton("ОК",
                        DialogInterface.OnClickListener { dialog, id -> dialog.cancel() })
                val alert = builder.create()
                alert.show()
            }
            else {
                db?.tableDao()?.insertRow(Table(null, text))
                requestInternet().execute(text(db!!.tableDao().getAll()))
            }
            editView?.setText("")
        })
    }

    fun text(list: List<Table>): ArrayList<String> {
        val res = ArrayList<String>()
        Log.d("len", list.size.toString())
        if (list.size != 0) {
            for (i in 0 until list.size) {
                res += list[i].column.toString()
            }
        }
        Log.d("res", res.toString())
        return res
    }

    inner class requestInternet : AsyncTask<ArrayList<String>, Void, ArrayList<String>>() {
        override fun doInBackground(vararg spec: ArrayList<String>): ArrayList<String>? {
            try {
                val res = spec[0]
                /*if (spec.size == 0) {
                    res += ""
                }*/
                return res

            } catch (e: IOException) {
                e.printStackTrace()
            }

            return null
        }

        override fun onPreExecute() {
            mListAdapter?.clear()
            super.onPreExecute()
        }

        override fun onPostExecute(l: ArrayList<String>) {
            mListAdapter?.setData(l)
            super.onPostExecute(l)
        }
    }
}
