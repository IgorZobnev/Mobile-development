package com.example.mysevenapplication

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mainTable")
data class Table (
    @PrimaryKey (autoGenerate = true) val id: Int?,
    @ColumnInfo (name = "data") val column: String? = null
)

