package com.example.mysevenapplication

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(version = 2, entities = arrayOf(Table::class))
    abstract class TestDB : RoomDatabase() {
    abstract fun tableDao(): TableDao
}