package com.example.mysevenapplication

import androidx.room.*

@Dao
interface TableDao {
    @Query("SELECT * FROM mainTable")
    fun getAll(): List<Table>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertRow(vararg row: Table)

    @Delete
    fun delete(row: Table)

    @Query("DELETE FROM mainTable WHERE id LIKE :id")
    fun deleteById(id: Int)


}