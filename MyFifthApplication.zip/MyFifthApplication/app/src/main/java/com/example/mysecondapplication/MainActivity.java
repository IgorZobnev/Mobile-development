package com.example.mysecondapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    public boolean flag = false;
    public boolean city = true;
    private TextView info;
    private TextView view;
    private String text;
    private final String WEATHER_URL = "https://newsapi.org/v2/top-headlines";
    private final String API_KEY = "e6dc13a3d1ea4dcd978e5b89206f8137";
    private final String RUSSIA = "ru";
    private final String GREAT_BRITAIN = "gb";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view = (TextView) findViewById(R.id.textView);
        text = getString(R.string.text_name);
        view.setText(text);

        info = (TextView) findViewById(R.id.info);

        Button button = findViewById(R.id.button);
        button.setOnClickListener(viewClickListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int item_id = item.getItemId();
        if (item_id == R.id.update) {
            Toast.makeText(this, R.string.updated, Toast.LENGTH_LONG).show();
            Uri uri = Uri.parse(WEATHER_URL).buildUpon()
                    .appendQueryParameter("country", city? RUSSIA : GREAT_BRITAIN)
                    .appendQueryParameter("apiKey", API_KEY)
                    .build();
            URL url = null;
            try {
                url = new URL(uri.toString());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            if (url != null) {
                new requestInternet().execute(url);
            }
            return true;
        }
        else if (item_id == R.id.changeLanguage) {
            switchLanguage();
            //text = getString(R.string.text_name);
            //view.setText(text);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    void switchLanguage() {
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration config = res.getConfiguration();
        Locale l = config.locale;
        if (l.getDisplayLanguage().equals("английский")) {
            config.setLocale(new Locale("ru"));
            Log.d("tag", "change lang ru");
        } else {
            config.setLocale(new Locale("en"));
            Log.d("tag", "change lang en");
        }
        res.updateConfiguration(config, dm);
        recreate();
    }

    View.OnClickListener viewClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            showPopupMenu(v);
        }
    };

    private void showPopupMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.inflate(R.menu.popupmenu);

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.firstAddress:
                        city = true;
                        return true;
                    case R.id.secondAddress:
                        city = false;
                        return true;
                    default:
                        return false;
                }
            }
        });
        popupMenu.show();
    }

    public class requestInternet extends AsyncTask<URL, Void, String> {
        @Override
        protected String doInBackground(URL... urls) {
            try {
                String responseStr = getResponseFromHttpUrl(urls[0]);
                Log.d("tag", responseStr);
                String infoStr = getInfoFromJson(responseStr);
                Log.d("tag", infoStr);
                return infoStr;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            if (city)
                info.setText(String.format(getString(R.string.RF), s));
            else
                info.setText(String.format(getString(R.string.UK), s));

            super.onPostExecute(s);
        }
    }

    public static String getResponseFromHttpUrl(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            }
            else {
                return null;
            }
        }
        finally {
            urlConnection.disconnect();
        }
    }

    String getInfoFromJson(String jsonStr) {
        try {
            JSONObject infoObj = new JSONObject(jsonStr);
            JSONArray info_predictions = infoObj.getJSONArray("articles");
            String inform = "";// = info_predictions.getJSONObject(0).getString ("main");
            for (int i = 0; i < info_predictions.length(); i++) {
                String info;
                if (info_predictions.getJSONObject(i).getString("author").isEmpty() || info_predictions.getJSONObject(i).getString("author").equals("null"))
                    info = "No author listed: \"" + info_predictions.getJSONObject(i).getString("title") + "\"";
                else
                    info = info_predictions.getJSONObject(i).getString("author") + ": \"" + info_predictions.getJSONObject(i).getString("title") + "\"";
                if (i != info_predictions.length())
                    info += "\n";
                inform += info;
            }
            return inform;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
