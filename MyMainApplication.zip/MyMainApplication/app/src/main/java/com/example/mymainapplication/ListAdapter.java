package com.example.mymainapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

class ListAdapter extends RecyclerView.Adapter<ElemViewHolder> {
    Context context;

    private ArrayList<String> data;

    public ListAdapter() {
        data = new ArrayList<>();
    }

    @Override
    public ElemViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        context = viewGroup.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.list_item, viewGroup, false);
        return new ElemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ElemViewHolder holder, int index) {
        final String str = data.get(index);
        int i = 0;
        while (i < str.length() && str.charAt(i) != '\t')
            i++;
        String answer = str.substring(0, i);
        holder.textView.setText(answer);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent intent = new Intent(context, InformActivity.class);
                intent.putExtra("stringName", str);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    void clear() {
        data.clear();
        notifyDataSetChanged();
    }

    void setData(ArrayList<String> data) {
        if (data == null) {
            data = new ArrayList<>();
        }
        this.data = data;
        notifyDataSetChanged();
    }
}
