package com.example.mymainapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.AsyncTaskLoader;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<String>>, SharedPreferences.OnSharedPreferenceChangeListener{
    private TextView view;
    private String text = "ru";
    private String author;
    private final String WEATHER_URL = "https://newsapi.org/v2/top-headlines";
    private final String API_KEY = "e6dc13a3d1ea4dcd978e5b89206f8137";
    private RecyclerView mItemsList;
    private ListAdapter mListAdapter;

    private final int MODE_ON_SAVE_INSTANCE = 2;
    private final int MODE_STATIC_VAR = 3;
    private final int UNIQUE_LOADER_ID = 111;

    static String staticVar = "";
    static boolean flag = true;

    String number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editText = (EditText) findViewById(R.id.cryptovalue);

        Button load = findViewById(R.id.load);
        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text = editText.getText().toString();
                Log.d("spec tag", text);
                refresh();
            }
        });

        author = getString(R.string.author);

        mItemsList = (RecyclerView) findViewById(R.id.my_recycler_view);

        LinearLayoutManager gridLayoutManager = new LinearLayoutManager(this);
        mItemsList.setLayoutManager(gridLayoutManager);

        mListAdapter = new ListAdapter();
        mItemsList.setAdapter(mListAdapter);
        mItemsList.setHasFixedSize(true);

        int mode = getPreferences(MODE_PRIVATE).getInt("mode", -1);
        if (mode == MODE_STATIC_VAR)
            view.setText(staticVar);
        if (mode == MODE_ON_SAVE_INSTANCE)
            view.setText(savedInstanceState.getString("data"));

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);

        String language = sharedPreferences.getString("list", "");
        Log.d("lang", language);

        if (flag) {
            if (language.equals("ru"))
                switchLanguage("английский");
            else
                switchLanguage("en");
            flag = false;
        }

        number = sharedPreferences.getString("count", "5");

        TextView url = (TextView) findViewById(R.id.url);
        url.setText("https://yandex.ru/news");
        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWebPage("https://yandex.ru/news");
            }
        });
    }

    public void openWebPage(String url) {
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        int mode = getPreferences(MODE_PRIVATE).getInt("mode", -1);
        if (mode == MODE_ON_SAVE_INSTANCE) {
            staticVar = view.getText().toString();
            outState.putString("data", "onSave");
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int item_id = item.getItemId();
        if (item_id == R.id.update) {
            refresh();
            return true;
        }
        else if (item_id == R.id.settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    void switchLanguage (String s) {
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration config = res.getConfiguration();
        Locale l = config.locale;
        if (s.equals("английский")) {
            Log.d("язык", "русский");
            config.setLocale(new Locale("ru"));
        } else {
            Log.d("язык", "english");
            config.setLocale(new Locale("en"));
        }
        res.updateConfiguration(config, dm);
        recreate();
    }

    public int[] indexes(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n')
                count++;
        }
        int[] indexes = new int[count];
        count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '\n') {
                indexes[count] = i;
                count++;
            }
        }
        return indexes;
    }

    @SuppressLint("StaticFieldLeak")
    @NonNull
    @Override
    public Loader<ArrayList<String>> onCreateLoader(int i, final @Nullable Bundle args) {
        return new AsyncTaskLoader<ArrayList<String>>(this) {
            String url;

            @Override
            protected void onStartLoading() {
                Log.d("tag", "onStartLoading");
                if (args == null) {
                    return;
                }
                Log.d("tag", "args not null");
                mListAdapter.clear();
                url = args.getString("data");
                // show loading indicator
                forceLoad();
            }

            @Override
            public ArrayList<String> loadInBackground() {
                try {
                    Uri uri = Uri.parse(WEATHER_URL).buildUpon()
                            .appendQueryParameter("country", !text.isEmpty() ? text : "ru")
                            .appendQueryParameter("apiKey", API_KEY)
                            .build();
                    URL url = null;
                    try {
                        url = new URL(uri.toString());
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    ArrayList<String> res = new ArrayList<>();
                    String responseStr = getResponseFromHttpUrl(url);
                    Log.d("tag", responseStr);
                    String infoStr = getInfoFromJson(responseStr);
                    Log.d("tag", infoStr);
                    int[] index = indexes(infoStr);
                    for (int i = 0; i < index.length; i++) {
                        if (i == 0) {
                            res.add(infoStr.substring(0, index[i]));
                        }
                        else {
                            res.add(infoStr.substring(index[i - 1] + 1, index[i]));
                        }
                    }
                    return res;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<String>> loader, ArrayList<String> l) {
        mListAdapter.setData(l);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<String>> loader) {
    }

    void refresh() {
        Toast.makeText(this, R.string.updated, Toast.LENGTH_LONG).show();
        download();
    }

    void download() {
        Bundle asyncTaskLoaderParams = new Bundle();
        asyncTaskLoaderParams.putString("country", !text.isEmpty() ? text : "ru");
        LoaderManager loaderManager = getSupportLoaderManager();
        Loader<ArrayList<String>> loader = loaderManager.getLoader(UNIQUE_LOADER_ID);
        if (loader == null) {
            loaderManager.initLoader(UNIQUE_LOADER_ID, asyncTaskLoaderParams, this);
        } else {
            loaderManager.restartLoader(UNIQUE_LOADER_ID, asyncTaskLoaderParams, this);
        }
    }

    public static String getResponseFromHttpUrl(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            }
            else {
                return null;
            }
        }
        finally {
            urlConnection.disconnect();
        }
    }

    String getInfoFromJson(String jsonStr) {
        try {
            JSONObject infoObj = new JSONObject(jsonStr);
            JSONArray info_predictions = infoObj.getJSONArray("articles");
            int count = Integer.parseInt(number) <= info_predictions.length() ? Integer.parseInt(number) :
                    info_predictions.length();
            Log.d("count", Integer.toString(count));
            String inform = "";
            for (int i = 0; i < count; i++) {
                String info;
                if (info_predictions.getJSONObject(i).getString("author").isEmpty() || info_predictions.getJSONObject(i).getString("author").equals("null")) {
                    info = author + " \"" + info_predictions.getJSONObject(i).getString("title") + "\" \t" +
                            info_predictions.getJSONObject(i).getString("description") + "\t" + info_predictions.getJSONObject(i).getString("url");
                }
                else {
                    info = info_predictions.getJSONObject(i).getString("author") + ": \"" + info_predictions.getJSONObject(i).getString("title") + "\" \t" +
                            info_predictions.getJSONObject(i).getString("description") + "\t" + info_predictions.getJSONObject(i).getString("url");

                }
                inform += (info.replace('\n', '\t') + '\n');
            }
            return inform;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        String language = sharedPreferences.getString("list", "");
        Log.d("lang1", language);

        if (language.equals("ru"))
            switchLanguage("английский");
        else
            switchLanguage("english");

        number = sharedPreferences.getString("count", "5");
    }
}