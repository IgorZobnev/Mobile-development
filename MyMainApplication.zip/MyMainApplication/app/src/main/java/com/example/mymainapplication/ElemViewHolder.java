package com.example.mymainapplication;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

class ElemViewHolder extends RecyclerView.ViewHolder{
    TextView textView;

    public ElemViewHolder(View itemView){
        super(itemView);
        textView = (TextView) itemView.findViewById(R.id.info);
    }
}