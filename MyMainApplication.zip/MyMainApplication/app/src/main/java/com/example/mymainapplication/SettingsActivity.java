package com.example.mymainapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.Log;

public class SettingsActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    SettingsFragment settingsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        settingsFragment = new SettingsFragment();

        getFragmentManager().beginTransaction()
                .replace(android.R.id.content, settingsFragment).commit();

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        sharedPreferences.registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        Log.d("part2", "OnSharedPreferenceChanged");
        Preference preference = settingsFragment.findPreference(s);
        if (preference != null) {
            if (preference instanceof ListPreference || preference instanceof EditTextPreference) {
                Log.d("tag", "kek1");
                String value = sharedPreferences.getString(preference.getKey(), "");
                setPreferenceSummary(preference, value);
            }
        }
    }

    private void setPreferenceSummary(Preference preference, String value) {
        Log.d("part2", "setPreferenceSummary");
        if (preference != null) {
            if (preference instanceof ListPreference) {
                Log.d("part2", "ListPreference");
                ListPreference listPreference = (ListPreference) preference;
                int prefIndex = listPreference.findIndexOfValue(value);
                if (prefIndex >= 0) {
                    listPreference.setSummary(listPreference.getEntries()[prefIndex]);
                }
            }
            else if (preference instanceof EditTextPreference) {
                Log.d("part2", "EditTextPreference");
                EditTextPreference editTextPreference = (EditTextPreference) preference;
                String string = editTextPreference.getText();
                Log.d("string", string);
                editTextPreference.setSummary(string);
            }
        }
    }
}